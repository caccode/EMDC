clear all
close all
clc
%---------------------------------------------------------------------------------
FONTSIZE = 0.315;          % ��λΪ����;
% "0.2462" ��Ӧ�ں���С6��; "0.28097" ��Ӧ�ں���6��;
% "0.315"  ��Ӧ�ں���С5��; "0.3698" ��Ӧ�ں���5��;
LINEWIDTH_AXES = 0.8;      %  140/42;  % corresponding to 0.140mm
LINEWIDTH_WAVE = 1.0;      %  180/42;  % corresponding to 0.180mm
%--------------------------------------------------------------------------------
%%
addpath('fun_graph','funs','y_tsne');
datapath = '/Users/qiang/Documents/MATLAB/dataset/MultiView/';
%% BDGP imshow
ds = strcat(datapath,'BDGP_fea.mat');
load (ds);

[num,~]=size(Y);
c=length(unique(Y));
V=size(X,1);
% for ii = 1 :V
%     X{ii}=full(X{ii});
%     [mappedX,~] = tsne(X{ii});
%     figure('name',['Orgview',num2str(ii),'_',num2str(size(X{ii},2))]);
%     gscatter(mappedX(:,1), mappedX(:,2),Y);
%     set(gca,'FontSize',15);
% end
% 
% % LMGEC tsne
% load gt_BDGP_LMGEC.mat
% for ii = 1 :V
%     [mappedX,~] = tsne(X{ii});
%     figure('name',['LMGECview',num2str(ii),'_',num2str(size(X{ii},2))]);
%     gscatter(mappedX(:,1), mappedX(:,2),gt_BDGP_LMGEC);
%     set(gca,'FontSize',15);
% end

numAnchor = 4;
numNearestAnchors = 5;
for lambda = [1e-3,1e-2,1e-1,1,1e1,1e2,1e3]
[predY,result,runtime,w,obj] = run_multiFDC_tsne(X,Y,numAnchor,numNearestAnchors,lambda,'SVD_km','BKHK');

% tsne
for ii = 1 :1
    [mappedX,~] = tsne(X{ii});
    figure('name',['Oursview',num2str(ii),'_',num2str(size(X{ii},2))]);
    gscatter(mappedX(:,1), mappedX(:,2),predY);
    set(gca,'FontSize',15);
end

end